﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtteamhome = new DataTable();
        DataTable dtteamaway = new DataTable();
        DataTable dtmatch = new DataTable();
        DataTable dtplayer = new DataTable();

        DataTable dtdgv = new DataTable();
        DataTable dtdmatch = new DataTable();
        DataTable dtteam = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("Team", "Team");
            dataGridView1.Columns.Add("Player", "Player");
            dataGridView1.Columns.Add("Type", "Type");

            dtmatch.Columns.Add("match_id");
            dtmatch.Columns.Add("match_date");
            dtmatch.Columns.Add("team_home");
            dtmatch.Columns.Add("team_away");
            dtmatch.Columns.Add("goal_home");
            dtmatch.Columns.Add("goal_away");
            dtmatch.Columns.Add("referee_id");
            dtmatch.Columns.Add("delete");

            //match_id, minute, team_id, player_id, type, delete

            dtdmatch.Columns.Add("match_id");
            dtdmatch.Columns.Add("minute");
            dtdmatch.Columns.Add("team_id");
            dtdmatch.Columns.Add("player_id");
            dtdmatch.Columns.Add("type");
            dtdmatch.Columns.Add("delete");

            sqlConnect = new MySqlConnection(
                $"server=localhost;" +  
                $"uid=root;" +
                $"pwd=SQLcelin040205.;" + 
                $"database=premier_league"); 
            sqlConnect.Open();
            sqlConnect.Close();

            cb_teamhome.SelectedIndexChanged -= cb_teamhome_SelectedIndexChanged;
            cb_teamaway.SelectedIndexChanged -= cb_teamaway_SelectedIndexChanged;

            //team home
            string team = "select distinct team_id, team_name \r\nfrom `match` m\r\njoin team t\r\non t.team_id = m.team_home order by 1";
            sqlCommand = new MySqlCommand(team, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteamhome);

            cb_teamhome.DataSource = dtteamhome;
            cb_teamhome.ValueMember = "team_id";
            cb_teamhome.DisplayMember = "team_name";

            //team away
            string team2 = "select distinct team_id, team_name \r\nfrom `match` m\r\njoin team t\r\non t.team_id = m.team_away order by 1";
            sqlCommand = new MySqlCommand(team2, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteamaway);

            cb_teamaway.DataSource = dtteamaway;
            cb_teamaway.ValueMember = "team_id";
            cb_teamaway.DisplayMember = "team_name";

            cb_teamhome.SelectedIndexChanged += cb_teamhome_SelectedIndexChanged;
            cb_teamaway.SelectedIndexChanged += cb_teamaway_SelectedIndexChanged;

            cb_teamhome.SelectedIndex = -1;
            cb_teamaway.SelectedIndex = -1;
        }
        private void GenerateMatchID()
        {
            int selectedYear = datetime.Value.Year;

            string sql = $"SELECT IFNULL(MAX(RIGHT(match_id, 3)), '000') as last_three " +
                         $"FROM `match` " +
                         $"WHERE YEAR(match_date) = {selectedYear};";

            sqlCommand = new MySqlCommand(sql, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);

            int lastThreeDigits = Convert.ToInt32(dt.Rows[0]["last_three"]);
            int newMatchNumber = lastThreeDigits + 1;
            string newMatchID = $"{selectedYear}{newMatchNumber:D3}";

            tb_matchid.Text = newMatchID;
        }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamaway.Text == cb_teamhome.Text && cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
                MessageBox.Show("SAME TEAM!");
                cb_teamaway.Text = "";
                cb_teamhome.Text = "";
            }

            if (cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
               GenerateMatchID();

                //TEAM
                dtteam.Rows.Clear();
                string sql2 = $"select team_id, team_name\r\nfrom team\r\nwhere team_name = '{cb_teamhome.Text}' or team_name = '{cb_teamaway.Text}';";
                sqlCommand = new MySqlCommand(sql2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtteam);
                cb_team.DataSource = dtteam;
                cb_team.ValueMember = "team_id";
                cb_team.DisplayMember = "team_name";
                cb_team.Text = "";

            }
           
        }

        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamaway.Text == cb_teamhome.Text && cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
                MessageBox.Show("SAME TEAM!");
                cb_teamaway.Text = "";
                cb_teamhome.Text = "";
            }

            if (cb_teamhome.Text != "" && cb_teamaway.Text != "")
            {
                GenerateMatchID();

                //TEAM
                dtteam.Rows.Clear();
                string sql2 = $"select team_id, team_name\r\nfrom team\r\nwhere team_name = '{cb_teamhome.Text}' or team_name = '{cb_teamaway.Text}';";
                sqlCommand = new MySqlCommand(sql2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtteam);
                cb_team.DataSource = dtteam;
                cb_team.ValueMember = "team_id";
                cb_team.DisplayMember = "team_name";
                cb_team.Text = "";

            }
        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            //PLAYER
            dtplayer.Rows.Clear();
            cb_type.Items.Clear();
            string sql2 = $"select player_id , player_name " +
                $"from player p " +
                $"join team t " +
                $"on p.team_id = t.team_id " +
                $"where team_name = '{cb_team.Text}';";
            sqlCommand = new MySqlCommand(sql2, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtplayer);
            cb_player.DataSource = dtplayer;
            cb_player.ValueMember = "player_id";
            cb_player.DisplayMember = "player_name";
            //TYPE
            cb_type.Items.Add("GO");
            cb_type.Items.Add("GP");
            cb_type.Items.Add("GW");
            cb_type.Items.Add("CR");
            cb_type.Items.Add("CY");
            cb_type.Items.Add("PM");
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                dataGridView1.Rows.RemoveAt(row.Index);
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string date = datetime.Value.ToString("yyyy-MM-dd");
            dataGridView1.Rows.Add(cb_team.Text, cb_player.Text, cb_type.Text);
            dtdmatch.Rows.Add(tb_matchid.Text, tb_minute.Text, cb_team.SelectedValue, cb_player.SelectedValue,
                cb_type.Text, "0");
            dgv_coba.DataSource = dtdmatch;
            
            
        }

        //ditukar dmatch sama match 
        private void btn_insert_Click(object sender, EventArgs e)
        {
            string date = datetime.Value.ToString("yyyy-MM-dd");

            // Initialize goal counts
            int goal_home = 0;
            int goal_away = 0;

            try
            {
                sqlConnect.Open();
                for (int i = 0; i < dtdmatch.Rows.Count; i++)
                {
                    string teamId = dtdmatch.Rows[i]["team_id"].ToString();
                    string type = dtdmatch.Rows[i]["type"].ToString();

                    if (teamId == cb_teamhome.SelectedValue.ToString())
                    {
                        if (type == "GO" || type == "GP")
                        {
                            goal_home++;
                        }
                        else if (type == "GW")
                        {
                            goal_away++;
                        }
                    }
                    else if (teamId == cb_teamaway.SelectedValue.ToString())
                    {
                        if (type == "GO" || type == "GP")
                        {
                            goal_away++;
                        }
                        else if (type == "GW")
                        {
                            goal_home++;
                        }
                    }
                }

                // Insert into match table
                string sql2 = "INSERT INTO `match` (match_id, match_date, team_home, team_away, goal_home, goal_away, referee_id, `delete`) " +
                              "VALUES (@MatchId, @MatchDate, @TeamHome, @TeamAway, @GoalHome, @GoalAway, @Ref, @Delete);";

                using (MySqlCommand sqlCommand = new MySqlCommand(sql2, sqlConnect))
                {
                    sqlCommand.Parameters.AddWithValue("@MatchId", tb_matchid.Text);
                    sqlCommand.Parameters.AddWithValue("@MatchDate", date);
                    sqlCommand.Parameters.AddWithValue("@TeamHome", cb_teamhome.SelectedValue);
                    sqlCommand.Parameters.AddWithValue("@TeamAway", cb_teamaway.SelectedValue);
                    sqlCommand.Parameters.AddWithValue("@GoalHome", goal_home);
                    sqlCommand.Parameters.AddWithValue("@GoalAway", goal_away);
                    sqlCommand.Parameters.AddWithValue("@Ref", "M002");
                    sqlCommand.Parameters.AddWithValue("@Delete", 0);

                    sqlCommand.ExecuteNonQuery();
                }

                for (int i = 0; i < dtdmatch.Rows.Count; i++)
                {
                    string sql3 = "INSERT INTO dmatch (match_id, minute, team_id, player_id, type, `delete`) " +
                                  "VALUES (@MatchId, @Minute, @TeamId, @PlayerId, @Type, @Delete);";

                    sqlCommand = new MySqlCommand(sql3, sqlConnect);
                    sqlCommand.Parameters.AddWithValue("@MatchId", dtdmatch.Rows[i]["match_id"]);
                    sqlCommand.Parameters.AddWithValue("@Minute", dtdmatch.Rows[i]["minute"]);
                    sqlCommand.Parameters.AddWithValue("@TeamId", dtdmatch.Rows[i]["team_id"]);
                    sqlCommand.Parameters.AddWithValue("@PlayerId", dtdmatch.Rows[i]["player_id"]);
                    sqlCommand.Parameters.AddWithValue("@Type", dtdmatch.Rows[i]["type"]);
                    sqlCommand.Parameters.AddWithValue("@Delete", 0);

                    sqlCommand.ExecuteNonQuery();
                }

             
                MessageBox.Show("Inserted into database table `match` and `dmatch`");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            { 
                if (sqlConnect.State == ConnectionState.Open)
                {
                    sqlConnect.Close();
                }
            }
        }

        private void datetime_ValueChanged(object sender, EventArgs e)
        {
            GenerateMatchID();
            var fixedDate = new DateTime(2016, 2, 14);
            if (datetime.Value < fixedDate)
            {
                MessageBox.Show("Date can't be less than 14 Februari 2016");
            }
        }
    }
}
